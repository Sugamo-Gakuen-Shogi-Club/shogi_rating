
export enum ActivityType {
  MATCH_WIN = 'MATCH_WIN',
  MATCH_LOSS = 'MATCH_LOSS',
  MATCH_DRAW = 'MATCH_DRAW',
  ATTENDANCE = 'ATTENDANCE',
  CONTRIBUTION = 'CONTRIBUTION',
  BONUS = 'BONUS'
}

export interface AchievementDef {
  id: string;
  name: string;
  description: string;
  conditionType: 'WINS' | 'STREAK' | 'RATE' | 'DAYS' | 'MATCHES' | 'SPECIAL';
  threshold: number;
}

export interface IconDef {
  id: string;
  char: string;
  name: string;
  conditionDescription: string;
  type: 'DEFAULT' | 'RATE' | 'WINS' | 'STREAK' | 'SPECIAL' | 'MATCHES' | 'DAYS';
  category: 'DEFAULT' | 'SHOGI' | 'CHESS' | 'SPECIAL' | 'RANK';
  threshold?: number;
}

export interface RateHistoryPoint {
  date: string;
  rate: number;
}

export enum Season {
  TERM_1_EARLY = '１学期前半',
  TERM_1_LATE = '１学期後半',
  SUMMER_CAMP = '夏季合宿',
  TERM_2_EARLY = '２学期前半',
  TERM_2_LATE = '２学期後半',
  WINTER_CAMP = '冬季合宿',
  TERM_3 = '３学期',
  SPRING_CAMP = '春季合宿'
}

export enum EventType {
  STANDARD = '通常イベント',
  FACTION_WAR = '紅白戦'
}

export type SystemTitle = 'MASTER' | 'RISING_STAR' | 'GRINDER' | 'GIANT_KILLER';

export interface TitleDef {
    id: SystemTitle;
    name: string;
    english: string;
    description: string;
    color: string;
}

export interface User {
  id: string;
  name: string;
  reading?: string;
  isNewMember: boolean;
  // ★ 追加: 休眠フラグ（falseのとき退部扱い）
  isActive: boolean;
  rate: number;
  faction?: 'RED' | 'WHITE';
  isGeneral: boolean;

  // Seasonal Snapshot
  seasonStartRate: number;
  seasonStartPoints: number;

  // System Title (The Four Kings)
  systemTitle: SystemTitle | null;

  // Icon System
  activeIconId: string;
  unlockedIcons: string[];

  // Point Breakdown
  totalPoints: number;
  pointsMatch: number;
  pointsAttendance: number;
  pointsSpecial: number;

  monthlyPoints: number;
  eventPoints: number;

  currentStreak: number;
  maxStreak: number;
  wins: number;
  losses: number;
  draws: number;
  lastAttendance: string | null;
  activityDays: number;
  rateHistory: RateHistoryPoint[];
  achievements: string[];
  activeTitle: string | null;
  avatarColor: string;
}

export interface MatchRecord {
  id: string;
  date: string;
  player1Id: string;
  player2Id: string;
  result: 'PLAYER1_WIN' | 'PLAYER2_WIN' | 'DRAW';
  p1RateChange: number;
  p2RateChange: number;
  p1PointsEarned: number;
  p2PointsEarned: number;
  isDuel?: boolean;
}

export interface SystemSettings {
  adminPin: string;
  eventName: string | null;
  eventType: EventType;
  eventEndsAt: string | null;
  eventMultiplier: number;
  currentSeason: Season;
  lastMonthlyReset: string;
  lastTitleUpdate: string | null;
}

export interface ActivityLog {
  id: string;
  userId: string;
  type: ActivityType;
  points: number;
  description: string;
  date: string;
}

export interface PointBreakdown {
    base: number;
    streakBonus: number;
    newMemberBonus: number;
    eventMultiplier: number;
    spamPenalty: number;
    total: number;
}

export interface MatchProcessResult {
  p1RateChange: number;
  p2RateChange: number;
  p1PointsDetail: PointBreakdown;
  p2PointsDetail: PointBreakdown;
  p1PointsEarned: number;
  p2PointsEarned: number;
  newAchievementsP1: AchievementDef[];
  newAchievementsP2: AchievementDef[];
  newIconsP1: IconDef[];
  newIconsP2: IconDef[];
  isDuel: boolean;
  result: 'PLAYER1_WIN' | 'PLAYER2_WIN' | 'DRAW';
}

export interface AttendanceResult {
  success: boolean;
  newAchievements: AchievementDef[];
  newIcons: IconDef[];
  message: string;
}

export interface BackupData {
  users: User[];
  matches: MatchRecord[];
  settings: SystemSettings;
  logs: ActivityLog[];
  timestamp: string;
}

export interface RivalData {
  opponentId: string;
  opponentName: string;
  wins: number;
  losses: number;
  draws: number;
  total: number;
  winRate: number;
}

// ★ 追加: 同期ステータス
export type SyncStatus = 'SYNCED' | 'SYNCING' | 'PENDING' | 'ERROR' | 'NEVER';

export interface SyncMeta {
  status: SyncStatus;
  lastSync: string | null;
  localTimestamp: string | null;
  pendingChanges: number;
  lastError?: string;
}

export interface AutoBackupEntry {
  date: string;
  key: string;
  userCount: number;
  matchCount: number;
  timestamp: string;
}
